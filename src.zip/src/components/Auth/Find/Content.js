import React from 'react';


const Content = ({children}) => (
    <div>
        {children}
    </div>
);

export default Content;