export { default as IDTable } from './IDTable';
export { default as Label } from './Label';