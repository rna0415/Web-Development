import React from 'react';


const Content1 = ({children}) => (
    <div>
        {children}
    </div>
);

export default Content1;