export { default as Wrapper1 } from './Wrapper1';
export { default as Content1 } from './Content1';
export { default as Tab1 } from './Tab1';
export { default as Infotab1 } from './Infotab1';
export { default as Infotab2 } from './Infotab2';
export { default as Info1 } from './Info1';
export { default as Label1 } from './Label1';
export { default as Input1 } from './Input1';
export { default as Input2 } from './Input2';
export { default as Check } from './Check';
export { default as CompanyNo } from './CompanyNo';
export { default as SelectWithLabel1 } from './SelectWithLabel1';
export { default as SelectWithLabel2 } from './SelectWithLabel2';


// export { default as SelectWithLabel} from '../SelectWithLabel';