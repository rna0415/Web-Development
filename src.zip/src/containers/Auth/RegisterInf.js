import React, { Component } from 'react';
import { withRouter } from "react-router-dom"
import {} from '../../components/Auth';
import { AuthWrapper2 } from '../../components/Auth';

class RegisterInf extends Component {
    render() {
        return (
            <AuthWrapper2 title="인플루언서 회원가입">
                <div>
                    Home
                </div>
            </AuthWrapper2>
        );
    }
}

export default withRouter(RegisterInf);